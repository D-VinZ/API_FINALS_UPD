document.getElementById('next').onclick = function(){
  let lists = document.querySelectorAll('.item');
  document.getElementById('slide').appendChild(lists[0]);
  
  // Check if modal is open, then fade it out
  const modal = document.getElementById('myModal');
  if (modal.style.display === 'block') {
      $(modal).fadeOut(1000); // Use jQuery fadeOut for a smooth effect
  }
}
  document.getElementById('prev').onclick = function(){
    let lists = document.querySelectorAll('.item');
    document.getElementById('slide').prepend(lists[lists.length - 1]);  const modal = document.getElementById('myModal');
  
  
    if (modal.style.display === 'block') {
        $(modal).fadeOut(1000); // Use jQuery fadeOut for a smooth effect
    }
  }


  
  

